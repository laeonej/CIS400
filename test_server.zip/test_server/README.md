# tic-tac-toe-server
 Node JS Socket.io Tic Tac Toe Server

## Description
- This repo contains server side code for tic tac toe.

## Output:

![Output](https://raw.githubusercontent.com/myvsparth/tic-tac-toe-server/master/output.png)

1. First Clone the Repo
2. npm install
3. npm start

- Front-End made in React JS which will be found at below repo
https://github.com/myvsparth/react-js-tic-tac-toe
